package com.gupaoedu.pattern.proxy;

/**
 * @Author: qingshan
 * @Date: 2019/3/7 14:56
 * @Description: 咕泡学院，只为更好的你
 */
public interface RentService {
    void rent(String str);
}
